class DashboardController < ApplicationController
  def home; end
end
