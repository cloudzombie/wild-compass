module InventoryHelper
end
