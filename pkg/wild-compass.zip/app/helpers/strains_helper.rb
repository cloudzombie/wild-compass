module StrainsHelper
end
