module LotsHelper
end
