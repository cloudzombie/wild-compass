module BagsHelper


end
