class AddPlantToLotId < ActiveRecord::Migration
  def change
  end
end
