require 'test_helper'

class PotsHelperTest < ActionView::TestCase
end
