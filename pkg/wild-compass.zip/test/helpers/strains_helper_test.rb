require 'test_helper'

class StrainsHelperTest < ActionView::TestCase
end
