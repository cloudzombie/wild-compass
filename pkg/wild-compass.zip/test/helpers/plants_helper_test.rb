require 'test_helper'

class PlantsHelperTest < ActionView::TestCase
end
