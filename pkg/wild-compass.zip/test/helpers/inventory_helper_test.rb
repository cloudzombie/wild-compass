require 'test_helper'

class InventoryHelperTest < ActionView::TestCase
end
