require 'test_helper'

class BagsHelperTest < ActionView::TestCase
end
