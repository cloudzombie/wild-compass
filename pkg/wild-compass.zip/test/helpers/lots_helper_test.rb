require 'test_helper'

class LotsHelperTest < ActionView::TestCase
end
