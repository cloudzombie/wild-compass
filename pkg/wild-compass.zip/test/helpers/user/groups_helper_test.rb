require 'test_helper'

class User::GroupsHelperTest < ActionView::TestCase
end
