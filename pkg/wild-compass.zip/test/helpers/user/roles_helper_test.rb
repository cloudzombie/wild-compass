require 'test_helper'

class User::RolesHelperTest < ActionView::TestCase
end
