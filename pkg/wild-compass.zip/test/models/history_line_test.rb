require 'test_helper'

class HistoryLineTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
