require 'test_helper'

class User::RoleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
