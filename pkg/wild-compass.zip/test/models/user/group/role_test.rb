require 'test_helper'

class User::Group::RoleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
