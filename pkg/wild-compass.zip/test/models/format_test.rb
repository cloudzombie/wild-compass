require 'test_helper'

class FormatTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
