require 'test_helper'

class PotTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
