require 'test_helper'

class CultivarTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
