require 'test_helper'

class LotTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
